package tr.gov.sg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HibernateSpringDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(HibernateSpringDataApplication.class, args);
	}

}
