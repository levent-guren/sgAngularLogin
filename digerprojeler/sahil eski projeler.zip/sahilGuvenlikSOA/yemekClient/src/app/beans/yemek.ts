export interface Yemek {
    id: number;
    adi: string;
    fiyat: number;
    kota: number;
}
