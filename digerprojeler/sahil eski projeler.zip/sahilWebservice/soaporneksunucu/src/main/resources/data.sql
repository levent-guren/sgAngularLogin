insert into gemi values (1, 'Dost', 'Korvet', 2007);
insert into gemi values (2, 'Elizabet', 'Kuru Yük', 2017);
insert into gemi values (3, 'Taytanik', 'Kruvaziyer', 2001);
insert into gemi values (4, 'Güven', 'Korvet', 2020);
insert into gemi values (5, 'Gemicik', 'Kontrol Bot', 2002);
