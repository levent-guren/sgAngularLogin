create table gemi (
	id integer primary key,
	adi varchar(255) not null,
	tipi varchar(255) not null,
	hizmete_baslama_yili number(4)
);