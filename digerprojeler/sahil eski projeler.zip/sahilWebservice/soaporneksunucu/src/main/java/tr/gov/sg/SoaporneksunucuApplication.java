package tr.gov.sg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoaporneksunucuApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoaporneksunucuApplication.class, args);
	}

}
