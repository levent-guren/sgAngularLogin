import { Component } from '@angular/core';

@Component({
  selector: 'app-gemi',
  templateUrl: './gemi.component.html',
  styleUrl: './gemi.component.scss'
})
export class GemiComponent {

}
