export interface Birlik {
    id: number;
    adi: string;
    il: string;
    toplamGemiSayisi: number;
}