package tr.gov.sg.model;

import lombok.Data;

@Data
public class Kaptan {
	private long tcNo;
	private String adi;
}
