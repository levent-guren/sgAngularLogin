package tr.gov.sg.dto;

import lombok.Data;

@Data
public class KaptanResponseDTO {
	private String adi;
}
