package tr.gov.sg.dto.gemi;

import lombok.Data;

@Data
public class Kaptan {
	private long tcNo;
	private String adi;
}
