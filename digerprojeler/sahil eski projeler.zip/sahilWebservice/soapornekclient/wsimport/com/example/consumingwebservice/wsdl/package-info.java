@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://tr.gov.sg/ws/gemi", elementFormDefault = jakarta.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.example.consumingwebservice.wsdl;
