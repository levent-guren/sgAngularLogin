package tr.gov.sg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoapornekclientApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoapornekclientApplication.class, args);
	}

}
