package tr.gov.sg.dto.gemi;

import lombok.Data;

@Data
public class GemiRequestDTO {
	private String ilAdi;
}
