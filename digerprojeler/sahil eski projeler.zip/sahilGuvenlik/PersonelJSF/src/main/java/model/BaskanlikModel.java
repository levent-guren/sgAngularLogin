package model;

import lombok.Data;

@Data
public class BaskanlikModel {
	private int id;
	private String ad;
	private String il;
}
