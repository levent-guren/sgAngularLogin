package config;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.faces.annotation.FacesConfig;

@ApplicationScoped
@FacesConfig
public class JSFConfig {

}
