package beans;

public enum Islem {
	TOPLA, CIKAR, CARP, BOL;
}
