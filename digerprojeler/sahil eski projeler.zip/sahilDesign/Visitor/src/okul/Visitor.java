package okul;

public interface Visitor {
	public void accept(Kisi kisi);
}
