package okul;

public interface Kisi {
	public void visit(Visitor visitor);

	public String getAdi();
}
