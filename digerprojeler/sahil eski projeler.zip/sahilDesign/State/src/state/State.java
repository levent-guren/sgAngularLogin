package state;

public interface State {
	public void hesapla(Uye uye);

	public int getAidat();
}
