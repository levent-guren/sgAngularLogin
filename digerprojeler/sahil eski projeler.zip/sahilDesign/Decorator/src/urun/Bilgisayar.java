package urun;

public class Bilgisayar extends Urun {

	public Bilgisayar(String adi, double fiyat) {
		super(adi, fiyat);
	}

}
