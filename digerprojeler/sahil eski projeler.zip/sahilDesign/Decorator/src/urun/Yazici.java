package urun;

public class Yazici extends Urun {

	public Yazici(String adi, double fiyat) {
		super(adi, fiyat);
	}

}
