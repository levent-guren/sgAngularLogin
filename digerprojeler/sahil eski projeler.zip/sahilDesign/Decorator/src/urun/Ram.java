package urun;

public class Ram extends Urun {

	public Ram(String adi, double fiyat) {
		super(adi, fiyat);
	}

}
