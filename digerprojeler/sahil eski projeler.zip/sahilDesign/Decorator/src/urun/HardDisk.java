package urun;

public class HardDisk extends Urun {

	public HardDisk(String adi, double fiyat) {
		super(adi, fiyat);
	}

}
