package personel;

public interface Composite {

}
