package belge;

public class Vekaletname extends Dokuman {

	public Vekaletname(String baslik) {
		super(baslik);
	}

}
