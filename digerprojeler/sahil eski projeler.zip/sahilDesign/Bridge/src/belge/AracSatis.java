package belge;

public class AracSatis extends Dokuman {

	public AracSatis(String baslik) {
		super(baslik);
	}

}
