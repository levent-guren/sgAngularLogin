package belge;

public class Ihtarname extends Dokuman {

	public Ihtarname(String baslik) {
		super(baslik);
	}

}
