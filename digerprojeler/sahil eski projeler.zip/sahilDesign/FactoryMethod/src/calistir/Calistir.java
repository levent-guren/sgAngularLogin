package calistir;

import yemek.Makarna;
import yemek.Pilav;

public class Calistir {
	public static void main(String[] args) {
		Makarna makarna = new Makarna();
		System.out.println(makarna);
		System.out.println("---------------------");
		Pilav pilav = new Pilav();
		System.out.println(pilav);

	}
}
