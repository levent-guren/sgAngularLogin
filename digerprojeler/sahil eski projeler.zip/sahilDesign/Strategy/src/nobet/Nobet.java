package nobet;

public interface Nobet {
	public void nobetTut(Personel personel);
}
