package nobet;

public class Karargah implements Nobet {

	@Override
	public void nobetTut(Personel personel) {
		System.out.println(
				personel.getAd() + " karargah nöbeti tutuyor");
	}

}
