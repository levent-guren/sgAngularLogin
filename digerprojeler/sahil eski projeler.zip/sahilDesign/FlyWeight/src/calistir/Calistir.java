package calistir;

import tone.ToneGenerator;

public class Calistir {
	public static void main(String[] args) {
		new ToneGenerator().dial("03122241344");
	}
}
