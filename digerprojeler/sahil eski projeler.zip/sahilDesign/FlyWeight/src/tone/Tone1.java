package tone;

public class Tone1 implements ITone {

	@Override
	public void dial() {
		System.out.println("1 çeviriliyor");
	}

}
