package tone;

public class Tone4 implements ITone {

	@Override
	public void dial() {
		System.out.println("4 çeviriliyor");
	}

}
