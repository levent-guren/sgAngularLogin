package tone;

public class Tone9 implements ITone {

	@Override
	public void dial() {
		System.out.println("9 çeviriliyor");
	}

}
