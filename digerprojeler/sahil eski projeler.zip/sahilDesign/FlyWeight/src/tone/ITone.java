package tone;

public interface ITone {
	public void dial();
}
