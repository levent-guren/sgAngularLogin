package tone;

public class Tone6 implements ITone {

	@Override
	public void dial() {
		System.out.println("6 çeviriliyor");
	}

}
