package tone;

public class Tone8 implements ITone {

	@Override
	public void dial() {
		System.out.println("8 çeviriliyor");
	}

}
