package tone;

public class Tone7 implements ITone {

	@Override
	public void dial() {
		System.out.println("7 çeviriliyor");
	}

}
