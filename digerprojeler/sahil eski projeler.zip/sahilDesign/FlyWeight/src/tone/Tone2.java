package tone;

public class Tone2 implements ITone {

	@Override
	public void dial() {
		System.out.println("2 çeviriliyor");
	}

}
