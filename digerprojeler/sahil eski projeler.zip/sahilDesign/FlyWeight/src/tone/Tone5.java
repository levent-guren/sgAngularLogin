package tone;

public class Tone5 implements ITone {

	@Override
	public void dial() {
		System.out.println("5 çeviriliyor");
	}

}
