package tone;

public class Tone0 implements ITone {

	@Override
	public void dial() {
		System.out.println("0 çeviriliyor");
	}

}
