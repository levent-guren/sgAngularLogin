package tone;

public class Tone3 implements ITone {

	@Override
	public void dial() {
		System.out.println("3 çeviriliyor");
	}

}
