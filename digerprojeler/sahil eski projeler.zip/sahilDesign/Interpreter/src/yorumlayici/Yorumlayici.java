package yorumlayici;

public interface Yorumlayici {
	public void yorumla(String ifade);
}
