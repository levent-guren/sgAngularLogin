package email;

public class Email {
	private String kimden;
	private String kime;
	private String baslik;
	private String icerik;

	public String getKimden() {
		return kimden;
	}

	public void setKimden(String kimden) {
		this.kimden = kimden;
	}

	public String getKime() {
		return kime;
	}

	public void setKime(String kime) {
		this.kime = kime;
	}

	public String getBaslik() {
		return baslik;
	}

	public void setBaslik(String baslik) {
		this.baslik = baslik;
	}

	public String getIcerik() {
		return icerik;
	}

	public void setIcerik(String icerik) {
		this.icerik = icerik;
	}

}
