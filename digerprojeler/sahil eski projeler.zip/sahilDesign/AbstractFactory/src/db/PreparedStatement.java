package db;

public interface PreparedStatement {
	public void execute();
}
