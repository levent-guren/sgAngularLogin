package calistir;

public class Calistir3 {
	public static void main(String[] args) {
		int x = 2;
		x = x++;
		System.out.println(x);
	}

}
