package calistir;

public class Calistir4 {
	public static void main(String[] args) {
		int x = 2;
		int y = x++ + x++ + ++x;
		System.out.println(x);
		System.out.println(y);
	}

}
