package calistir;

public class Calistir {
	public static void main(String[] args) {
		int sayi = 10;
		deneme(sayi);
		System.out.println(sayi);
	}

	private static void deneme(int sayi) {
		System.out.println(sayi);
		sayi++;
	}

}
