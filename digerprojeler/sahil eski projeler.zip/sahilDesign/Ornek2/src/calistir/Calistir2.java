package calistir;

public class Calistir2 {
	public static void main(String[] args) {
		String adi = "Kezban";
		deneme(adi);
		System.out.println(adi);
	}

	private static void deneme(String adi) {
		System.out.println(adi);
		adi = "Mülayim";
	}

}
