package builder;

public interface Builder {
	public Product getProduct();
}
