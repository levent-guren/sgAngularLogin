package builder;

public class WoodenHouseProduct extends Product {

	@Override
	public String toString() {
		return "WoodenHouseProduct [getFloorCount()=" + getFloorCount() + ", getType()=" + getType() + "]";
	}

}
