package builder;

public class ApartmentProduct extends Product {

	@Override
	public String toString() {
		return "ApartmentProduct [getFloorCount()=" + getFloorCount() + ", getType()=" + getType() + "]";
	}

}
