package hesaplayici;

public interface IHesapMakinesi {
	public int hesapla(int sayi1, int sayi2, char islem);
}
